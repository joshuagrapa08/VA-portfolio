export default function App() {
  return (
    <div style={{ padding: 20 }}>
      <h1>Joshua Grapa Portfolio</h1>
      <p>Virtual Assistant • Credentialing Analyst • Admin Support</p>

      <h2>About Me</h2>
      <p>
        Dedicated Virtual Assistant with experience in healthcare credentialing,
        admin tasks, and remote US-based work.
      </p>

      <h2>Skills</h2>
      <ul>
        <li>Data Entry</li>
        <li>Healthcare Credentialing</li>
        <li>Customer Support</li>
        <li>Google Workspace</li>
        <li>Microsoft Office</li>
      </ul>

      <h2>Experience</h2>
      <p>Credentialing Analyst - AMN Healthcare</p>
    </div>
  )
}
